//
// Created by salah on 1/4/2024.
//

#ifndef PROJECTPOST_COUT_H
#define PROJECTPOST_COUT_H


class cout {

};


#endif //PROJECTPOST_COUT_H
